Інструкція з прошивки Meshtastic пристроюю nRF52 (Faketec)
----------------------------------------------------
1. Підключіть до компʼютера за допомогою USB кабеля.
3. Двічі натисніть RESET на пристрої.
4. В системі має зʼявитися новий диск, як флешка.
5. Відкрийте файл  INFO_UF2.TXT та переконайтеся що версія завантажувальника (bootloader) >= 0.8. Якщо ні - оновіть його з https://github.com/adafruit/Adafruit_nRF52_Bootloader/releases .
6. Скопіюйте firmware.uf2 на той диск. Дочекайтеся копіювання файлу. Пристрій автоматично перезавантажиться.
7. Відкрийте мобільний або десктопний клієнт Meshtastic. Підключіться до нового пристрою.
8. Зіскануйтие QR код з https://wikimesh.in.ua/uk/home для базових налаштувань української мережі.
----------------------------------------------------

Якщо диск ніяк не зʼявляється → nrfutil dfu usb-serial -pkg firmware.zip -p /dev/ttyACM0 (https://www.nordicsemi.com/Products/Development-tools/nRF-Util).

----------------------------------------------------
Вихідний код / Source code (GNU GPL v3):
  Базується на Meshtastic firmware v2.7.21.1370b23
  https://github.com/meshtastic/firmware/tree/v2.7.21.1370b23
  Патч з усіма змінами: meshtastic-faketec-joystick-v2.7.21.1370b23.patch
  Ліцензія: GNU General Public License v3
  https://www.gnu.org/licenses/gpl-3.0.html
----------------------------------------------------

  --
  Юра C.
  https://meshtastic.net.ua
